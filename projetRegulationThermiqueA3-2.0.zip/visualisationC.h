#include "define.h" 
void visualisationC(float puissance_f);