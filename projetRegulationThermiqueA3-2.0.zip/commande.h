#include <windows.h>
#include <stdio.h>
#include "lib/ftd2xx.h"
void commande(FT_HANDLE ftHandle,FT_STATUS ftStatus,float puissance);