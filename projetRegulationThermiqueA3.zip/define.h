#ifndef DEFINE_H
#define DEFINE_H
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	float interieure;
	float exterieure;
}temp_t;

#endif