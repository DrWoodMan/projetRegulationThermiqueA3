#include "integration.h"
#include "regulation.h"
#include "visualisationT.h"
#include "visualisationC.h"
void integrationTest(int regul,temp_t tInit,int nIterations){

}
