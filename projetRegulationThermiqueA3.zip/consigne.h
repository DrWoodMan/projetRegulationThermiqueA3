#include "define.h" 
float consigne(float csgn);